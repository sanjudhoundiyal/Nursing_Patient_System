package Database.Patient;

public class PatientModel {


    private int patientId;
    private String patientName;
    private String gender;
    private String medicalHistory;
    private String preferredShift;


    // getters & setters
    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }


    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }


    public String getMedicalHistory() { return medicalHistory; }
    public void setMedicalHistory(String medicalHistory) { this.medicalHistory = medicalHistory; }


    public String getPreferredShift() { return preferredShift; }
    public void setPreferredShift(String preferredShift) { this.preferredShift = preferredShift; }
}



