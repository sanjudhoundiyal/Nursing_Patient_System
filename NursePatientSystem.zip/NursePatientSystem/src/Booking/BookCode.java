package Booking;

import Database.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class BookCode {


    public void createBooking(int nurseId, int patientId) {
        String sql = "INSERT INTO Booking(nurseId, patient_id, status) VALUES (?,?,?)";


        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {


            ps.setInt(1, nurseId);
            ps.setInt(2, patientId);
            ps.setString(3, "Pending");


            ps.executeUpdate();
            System.out.println("Booking Created Successfully");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}










