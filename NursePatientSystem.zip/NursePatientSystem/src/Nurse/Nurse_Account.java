package Nurse;

public class Nurse_Account {



    private String fullName;
    private String gender;
    private String mobileNumber;
    private String specializedSkills;
    private String availableShiftTypes;


    public String getFullName() {
        return fullName;
    }


    public void setFullName(String fullName) {
        this.fullName = fullName;
    }


    public String getGender() {
        return gender;
    }


    public void setGender(String gender) {
        this.gender = gender;
    }


    public String getMobileNumber() {
        return mobileNumber;
    }


    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }


    public String getSpecializedSkills() {
        return specializedSkills;
    }


    public void setSpecializedSkills(String specializedSkills) {
        this.specializedSkills = specializedSkills;
    }


    public String getAvailableShiftTypes() {
        return availableShiftTypes;
    }


    public void setAvailableShiftTypes(String availableShiftTypes) {
        this.availableShiftTypes = availableShiftTypes;
    }
}

