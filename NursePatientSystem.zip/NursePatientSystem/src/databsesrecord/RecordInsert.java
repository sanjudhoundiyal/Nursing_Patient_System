package databsesrecord;

import Database.DBConnection;
import Nurse.Nurse_Account;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class RecordInsert {

    public void saveNurse(Nurse_Account nurse) {


        String sql = "INSERT INTO  Nurse(fullName, gender, mobileNumber, specializedSkills, availableShiftTypes) VALUES (?,?,?,?,?)";


        Connection con = DBConnection.getConnection();


        if (con == null) {
            System.out.println(" Database connection failed");
            return;
        }


        try (PreparedStatement ps = con.prepareStatement(sql)) {


            ps.setString(1, nurse.getFullName());
            ps.setString(2, nurse.getGender());
            ps.setString(3, nurse.getMobileNumber());
            ps.setString(4, nurse.getSpecializedSkills());
            ps.setString(5, nurse.getAvailableShiftTypes());


            ps.executeUpdate();
            System.out.println("✅ Nurse saved successfully");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

