import Booking.BookCode;
import Nurse.Nurse_Account;
import databsesrecord.RecordInsert;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Nurse_Account nurse = new Nurse_Account();
        nurse.setFullName("Anita Sharma");
        nurse.setGender("Female");
        nurse.setMobileNumber("9876543210");
        nurse.setSpecializedSkills("ICU Care");
        nurse.setAvailableShiftTypes("Night");


//         RecordInsert  = new RecordInsert();
//        RecordInsert.saveNurse(nurse);


        BookCode bookingDAO = new BookCode();
        bookingDAO.createBooking(1, 1);
    }
        }

